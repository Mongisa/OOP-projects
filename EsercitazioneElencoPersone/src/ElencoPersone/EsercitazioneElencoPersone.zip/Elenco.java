/* IMPORT DA COMPLETARE */

package ElencoPersone;

public class Elenco {
    /* CODICE DA COMPLETARE */
    public void aggiungi(Persona p) {
        /* CODICE DA COMPLETARE */
    }

    @Override
    public String toString() {
        /* CODICE DA COMPLETARE */
    }

}
