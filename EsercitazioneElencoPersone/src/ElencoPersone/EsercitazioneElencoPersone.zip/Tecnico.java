/* IMPORT DA COMPLETARE */

package ElencoPersone;

?? Tecnico ?? {
    /* completare */
    public Tecnico (??) ?? {
        ??
    }


    /* completare con getter e toString */
}