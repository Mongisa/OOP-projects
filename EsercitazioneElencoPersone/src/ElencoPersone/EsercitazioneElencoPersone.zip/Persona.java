import java.time.LocalDate;
import java.util.Objects;

package ElencoPersone;

public class Persona {
    /* codice da completare */

    public Persona(String nome, LocalDate dataNascita, String codiceFiscale) {
        /* codice da completare */
    }

    public String getNome() {
        return nome;
    }

    public LocalDate getDataNascita() {
        return dataNascita;
    }

    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    @Override
    public int hashCode() {
        /* CODICE DA COMPLETARE */
    }

    @Override
    public boolean equals(Object obj) {
        /* CODICE DA COMPLETARE */
    }

    @Override
    public String toString() {
        return "Nome=" + nome + ", Data di nascita=" + dataNascita + ", Codice fiscale=" + codiceFiscale;
    }
}
